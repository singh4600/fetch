# Ecommerce_Automation_ReleaseB_George
### Clone the project:
```bash
git clone -b <BRANCH_NAME> https://<USERNAME>_asdauk@github.com/ASDA-QA-AUTOMATION/ecommerce-automation-george.git
```
#### ---------------Function Apps-------------
```bash
[G_OMS_FunApp_DSVstocksnapshots_IFDD_0004]
This 

```
   
```bash
[G_OMS_FunApp_DsvPoAckConfirmCancel_IFDD_0019] 
```

```bash
[G_OMS_FunApp_FusionProducts_IFDD_0003]
```

```bash
[G_OMS_FunApp_InventoryATPPublish_IFDD_0006_a_b]
```

```bash
[G_OMS_FunApp_InvSnap_IFDD_0001_0002_0048]
```

```bash
[G_OMS_FunApp_PoDsvXmlCsvConversion_IFDD_0018]
```

#### ---------------LogicApps---------------

```bash
[G_OMS_LogicApp_wf_0019_ship_cancel_IFDD_0019]
```

```bash
[G_OMS_LogicApp_wf_0019_ship_conf_IFDD_0019]
```

```bash

[G_OMS_LogicApp_wf_0018_a_po_ack_IFDD_18a]
(https://portal.azure.com/#view/WebsitesExtension/FunctionMenuBlade/~/monitor/resourceId//subscriptions/92e27b7c-7523-41c4-bfff-0eeb8256f6f5/resourceGroups/rg-oms-test-uks-01/providers/Microsoft.Web/sites/func-omsgeorgedsv-test-uks-01/functions/DsvPoAckConfirmCancel-0018a)

```

```bash
[G_OMS_LogicApp_wf_oms_george_byoms_to_sfcc_sapglfms_common_IFDD_0054]
```

#### ---------------PassThrouhAPI's---------------
  		
```bash
[G_OMS_PassThroughAPI_RealTime_ATP_Call_IFDD_52]
```

```bash
[G_OMS_PassThroughAPI_Reservation_Call_IFDD_53]
```

```bash
[G_OMS_PassThroughAPI_SFCC_BY_OMS_Order_Details_0032_b]
```

```bash
[G_OMS_PassThroughAPI_SFCC_BY_OMS_Order_History_IFDD_0032_a]
```

```bash
[G_OMS_PassThroughAPI_SFSC_BY_OMS_Order_History_IFDD_0032_c]
```

```bash
[G_OMS_PassThroughAPI_SFSC_BY_OMS_Order_Details_0032_d]
```

```bash
[G_OMS_PassThroughAPI_Sorted_IFDD_22_IFDD_13_b]
```
