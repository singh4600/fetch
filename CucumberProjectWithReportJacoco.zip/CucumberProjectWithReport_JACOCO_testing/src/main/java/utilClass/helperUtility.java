package utilClass;

import static io.restassured.RestAssured.given;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusReceiverAsyncClient;
import com.azure.messaging.servicebus.models.ServiceBusReceiveMode;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class helperUtility {
	private static final Logger log = LogManager.getLogger(helperUtility.class.getName());

	//----------------------------------AccessToken-------------------------------------


	public static String getServiceBusAccessToken(){
		ReadConfig config;
		config = new ReadConfig();
		RestAssured.baseURI = "https://login.microsoftonline.com/b63ee29f-aaa6-4d4e-8267-1d6dca9c0e43/oauth2/token";
		RequestSpecification https = RestAssured.given();
		https.multiPart("client_id", config.getLogAnalyticsClientId())
		.multiPart("client_secret",config.getLogAnalyticsClientSecret() )
		.multiPart("grant_type", config.getLogAnalyticsGrantType())
		.multiPart("resource", config.getServiceBusResource());
		https.post().then().statusCode(200);
		Response response = https.post();
		ResponseBody body = response.getBody();
		JsonPath jsnPath = body.jsonPath();
		String token = jsnPath.get("access_token");
		//System.out.println("Token: " + token);
		return  token;
	}

	public static String getLogAnalyicsAccessToken(){
		ReadConfig config;
		config = new ReadConfig();
		RestAssured.baseURI = "https://login.microsoftonline.com/b63ee29f-aaa6-4d4e-8267-1d6dca9c0e43/oauth2/token";
		RequestSpecification https = RestAssured.given();
		https.multiPart("client_id", config.getLogAnalyticsClientId())
		.multiPart("client_secret",config.getLogAnalyticsClientSecret() )
		.multiPart("grant_type", config.getLogAnalyticsGrantType())
		.multiPart("resource", config.getLogAnalyticsResource());
		https.post().then().statusCode(200);
		Response response = https.post();
		ResponseBody body = response.getBody();
		JsonPath jsnPath = body.jsonPath();
		String token = jsnPath.get("access_token");
		//  System.out.println("Token: " + token);
		return  token;
	}

	//--------------------------------------LogAnalyticsUtils--------------------------------------------------------------------

	private static JSONObject jsonObject;
	public static String Log;
	private static RequestSpecification requestSpecification;
	public static List<List<List<String>>> logResponse;
	private static Response response;
	final static String LogAnalytics_BaseURl="https://api.loganalytics.io/v1/workspaces/";
	final static String LogAnalytics_BasePath="2ace1b78-fd69-4b72-a055-0e11f19e90d7/query";

	public static void logInAzureLogAnalyticsForGettingResult() throws InterruptedException, IOException, ParseException {
		RestAssured.baseURI=LogAnalytics_BaseURl;
		requestSpecification = given().basePath(LogAnalytics_BasePath);
		requestSpecification.header("Authorization","Bearer " + getLogAnalyicsAccessToken() )
		.contentType(ContentType.JSON);
		requestSpecification.body(jsonObject.toJSONString());
		//log.info("------------------------Waiting for log to be displayed in Log Analytics-------------------------------------------------");
		Thread.sleep(2000); //TODO need to find alternative of sleep
		response =  requestSpecification.when().post();
		response.then();
		logResponse = response.jsonPath().getList("tables[0].rows");
		if(logResponse == null) {
//			System.out.println("Log == Null");
			Thread.sleep(30000);
			response = requestSpecification.when().post();
			response.then();
			logResponse = response.jsonPath().getList("tables[0].rows");
		} else if(logResponse.size()==0) {
			for (int i = 1; i < 60; i++) {
				if (logResponse.size() == 0) {
					//  System.out.println("Count" + i);
					response = requestSpecification.when().post();
					response.then();
					logResponse = response.jsonPath().getList("tables[0].rows");
					Thread.sleep(1000);
				} else
					break;
			}
		}
		response =  requestSpecification.when().post();
		response.then().assertThat().statusCode(200);
		logResponse = response.jsonPath().getList("tables[0].rows");
		Log =response.jsonPath().get().toString();
		//System.out.println("Log Result: " + logResponse);
		// System.out.println("log only ===="+log);
	}
	public static List<Object> log_Response=null;
	public List<Object> LogAnalyticsQuery(JSONObject Query) throws InterruptedException, IOException, ParseException {
		try {
			RestAssured.baseURI = LogAnalytics_BaseURl;
			requestSpecification = given().basePath(LogAnalytics_BasePath);
			requestSpecification.header("Authorization", "Bearer " + getLogAnalyicsAccessToken())
					.contentType(ContentType.JSON);
			//System.out.println(Query.toJSONString());
			requestSpecification.body(Query.toJSONString());
			log.info("==========================Waiting for log to be displayed in Log Analytics=================");
			Thread.sleep(2000); //TODO need to find alternative of sleep
			this.response = requestSpecification.when().post();
//		this.response.then().assertThat().statusCode(200);
			if (this.response.statusCode() == 200) {
				log_Response = this.response.jsonPath().getList("tables[0].rows");
			}
			if (log_Response == null) {
				log.info("Log is Null");
				this.response = requestSpecification.when().post();
				this.response.then();
				log_Response = this.response.jsonPath().getList("tables[0].rows");
			}
			if (log_Response.size() == 0) {
				for (int i = 1; i < 60; i++) {
					if (log_Response.size() == 0) {
						this.response = requestSpecification.when().post();
						this.response.then();
						log_Response = this.response.jsonPath().getList("tables[0].rows");
						Thread.sleep(1000);
					} else {
						if (i == 59) {
							log.info("Log is not available, Maximum Time Exceeded for query " + Query.toJSONString());
						}
						log.info("Waited " + i + " seconds for log LogAnalytics");
						break;
					}
				}
			} else {
				this.response.then();
				log_Response = this.response.jsonPath().getList("tables[0].rows");
			}
			return log_Response;
		}catch(Exception e)
		{
			log.error("Getting error in query from log analytics :: "+e.getMessage());
			Assert.fail(e.getStackTrace().toString());
			return log_Response;
		}
	}
	//    public JsonObject ConvertToJson(){
	//        JsonObject JsonObject=convertToJsonObject(response.jsonPath().get());
	//        return JsonObject;
	//    }

	public static void CreateQueryOfWorkFlowNameActionCallTime(String Path, String Logic_App_name, String ActionName,String time) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		String Query ="";
		Object obj;
		obj = parser.parse(new FileReader(System.getProperty("user.dir") + Path));
		jsonObject = (JSONObject)obj;
		Query = ReplaceWorkFlowNameActionCallTime((String)  jsonObject.get("query"),ActionName, Logic_App_name,time);
		jsonObject.put("query", Query);
//		System.out.println("Query:  "+ Query);
	}

	public static String ReplaceWorkFlowNameActionCallTime(String query, String ActionCall, String WorkFlowName,String time)
	{
		query = query.replace("WorkFlow",WorkFlowName);
		query = query.replace("Action_Call", ActionCall);
		query=query.replace("20230111082612",time);
		return query;
	}
	public static String ReplaceWorkFlowNameActionCallTime1(String query, String FunctionName, String StartDate,String EndDte){
		query = query.replace("startDate",StartDate);   
		query = query.replace("functionName", FunctionName);  
		query=query.replace("endDate",EndDte);  
		return query;
	}

	public static void CreateQueryOfWorkFlowNameActionCallTimefunapp(String Path, String FunctionName, String StartDate,String EndDte) throws IOException, ParseException {
		JSONParser parser = new JSONParser();   
		String Query ="";   
		Object obj;   
		obj = parser.parse(new FileReader(System.getProperty("user.dir") + Path));   
		jsonObject = (JSONObject)obj;  
		Query = ReplaceWorkFlowNameActionCallTime1((String)  jsonObject.get("query"),
				FunctionName, StartDate,EndDte);   
		jsonObject.put("query", Query);    
		System.out.println("Query:  "+ Query);
	}




	public static void CreateQueryOfFunctionAppStartTimeEndTime(String Path,String functionName, String startDate, String endDate) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		String Query ="";
		Object obj;
		obj = parser.parse(new FileReader(System.getProperty("user.dir") + Path));
		jsonObject = (JSONObject)obj;
		Query = ReplaceFunctionAppStartTimeEndTime((String)  jsonObject.get("query"),startDate, endDate,functionName);
		jsonObject.put("query", Query);
		System.out.println("Query:  "+ Query);
	}
	public static String ReplaceFunctionAppStartTimeEndTime(String query, String startDate, String endDate,String functionName)
	{
		query = query.replace("startDate",startDate);
		query = query.replace("endDate", endDate);
		query=query.replace("functionName",functionName);
		return query;
	}
	public static void CreateQueryOfOperationNameFileNameStartTimeEndTime(String Path,String OperationName,String FileName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		String Query ="";
		Object obj;
		obj = parser.parse(new FileReader(System.getProperty("user.dir") + Path));
		jsonObject = (JSONObject)obj;
		Query = ReplaceOperationNameFileNameStartTimeEndTime((String)  jsonObject.get("query"),OperationName,FileName);
		jsonObject.put("query", Query);
		//System.out.println("Query:  "+ Query);
	}
	private static String ReplaceOperationNameFileNameStartTimeEndTime(String query,String OperationName,String FileName)
	{
		query=query.replace("operationName",OperationName);
		query=query.replace("FileName",FileName);
		return query;
	}
	public static void CreateQueryOfIdentifierIdWorkFlow(String Path,String identifier, String WorkFlowName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		String Query ="";
		Object obj;
		obj = parser.parse(new FileReader(System.getProperty("user.dir") + Path));
		jsonObject = (JSONObject)obj;
		Query = ReplaceIdentifierIdWorkFlow((String)  jsonObject.get("query"),identifier, WorkFlowName);
		jsonObject.put("query", Query);
		System.out.println("Query:  "+ Query);
	}

	private static String ReplaceIdentifierIdWorkFlow(String Query, String identifier, String WorkFlowName)
	{
		Query = Query.replace("WorkFlow",WorkFlowName);
		Query = Query.replace("Identifier", identifier);
		return Query;
	}
	public void createQueryOfWorkFlowWithCorrelationId(String Path, String Logic_App_name, String Tracking_Id) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		String Query ="";
		Object obj;
		obj = parser.parse(new FileReader(Path));
		jsonObject = (JSONObject)obj;
		Query = ReplaceCorrelationId((String)  jsonObject.get("query"),Tracking_Id, Logic_App_name);
		jsonObject.put("query", Query);
		//System.out.println("Query:  "+ Query);
	}
	private String ReplaceCorrelationId(String query, String CorrelationId, String WorkFlowName)
	{
		query = query.replace("WorkFlow",WorkFlowName);
		query = query.replace("CorrelationID", CorrelationId);
		return query;
	}

	//---------------------------------------------CommonFunctions------------------------------------------------------------



	public static void RemoveReportJsoneFile() {
		try {
			ArrayList<String> jsonFiles = new ArrayList<>();
			File folder = new File("target/cucumber-reports/JsonReport");
			File[] listOfFiles = folder.listFiles();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].getName().contains(".json")) {
					jsonFiles.add("target/cucumber-reports/JsonReport" + listOfFiles[i].getName());
				}
			}

			for (String str : jsonFiles) {
				//log.info(str);

				if (str != null) {
					File file = new File(str);
					if (file.delete()) {
						// log.info(str + "->" + "File deleted successfully");
					} else {
						// log.info(str + "->" + "Failed to delete the file");
					}
				} else {
					// log.info("There is no files in Report directory to delete");
				}
			}
		} catch (Exception e) {
			//log.info("Target folder not available to delete report.json file");
		}
	}



	public String getPercentage(int count, int total) {
		//return String.format("%.1f", (count / (float) total) * 100)+"%";
		float percentage = (count / (float) total) * 100;
		if(percentage==100) {
			return String.format("%.0f", percentage )+ "%";
		}else {
			return String.format("%.4s", percentage )+ "%";
		}
	}


	/*  public static void activateApp() throws InterruptedException {
            PerfectoDriverManager.getDriver().activateApp("com.sml.clarity.mobile.x");
    }*/

	public static String getCurrentDate(){
		SimpleDateFormat format = new SimpleDateFormat("M/dd/YYYY");
		Date date = new Date();
		return format.format(date);
	}
	public static String sixDigitNumber(){
		return new DecimalFormat("000000").format(new Random().nextInt(999999));
	}

	//-----------------------------------------CommonUtils----------------------------------------------------------------
	public static String DateTimeFormater;
	public static String ChangedFileName=null;
	public static String DEFAULT_FILE=null;
	public static DateTimeFormatter dtf;
	public static LocalDateTime now;
	private static List<String> Lines = new ArrayList<String>();

	public static String setTimeFormat(String timestampFormat) {
		dtf = DateTimeFormatter.ofPattern(timestampFormat);
		now = LocalDateTime.now();
		DateTimeFormater = dtf.format(now);
		return DateTimeFormater;
	}
	public static String setPastDateFormat(String timestampFormat) {
		dtf = DateTimeFormatter.ofPattern(timestampFormat);
		now = LocalDateTime.now();
		DateTimeFormater = dtf.format(now.minusDays(1));
		return DateTimeFormater;
	}

	public static void setDuplicateFileNameWithTimeStamp(String fileNameBeforeTimeStamp,String timestampFormat, String path, String defaultFileName, String fileNameAfterTimeStamp) throws InterruptedException {
		String RenamedFileName = fileNameBeforeTimeStamp + setTimeFormat(timestampFormat) + fileNameAfterTimeStamp;
		File oldFile = new File(path + defaultFileName);
		File newFile = new File(path + RenamedFileName);
		ChangedFileName = newFile.getName();
		// System.out.println("File renamed to newfile successfully");
		System.out.println(ChangedFileName);
		Thread.sleep(2000);
	}


	public static void setRenamedFileNameWithTimeStamp(String fileNameBeforeTimeStamp,String timestampFormat, String path, String defaultFileName, String fileNameAfterTimeStamp) throws InterruptedException {
		String RenamedFileName = fileNameBeforeTimeStamp + setTimeFormat(timestampFormat) + fileNameAfterTimeStamp;
		File oldFile = new File(path + defaultFileName);
		File newFile = new File(path + RenamedFileName);

		if (oldFile.renameTo(newFile)) {
			ChangedFileName = newFile.getName();
			log.info("File renamed to newfile successfully :::::::: "+ChangedFileName);
		}
		Thread.sleep(2000);
	}
	public static void setRenamedFileNameWithPastTimeStamp(String fileNameBeforeTimeStamp,String timestampFormat, String path, String defaultFileName, String fileType, String Var) throws InterruptedException {

		String RenamedFileName = fileNameBeforeTimeStamp + setPastDateFormat(timestampFormat) + Var + fileType;
		//File to rename
		File oldFile = new File(path + defaultFileName);
		//File for rename
		File newFile = new File(path + RenamedFileName);
		ChangedFileName = newFile.getName();
		//Rename the specified file
		if (oldFile.renameTo(newFile)) {
			//System.out.println("File renamed to new-file successfully");
			System.out.println(ChangedFileName);
		}
		Thread.sleep(2000);
	}

	public static void setRenamedFileNameWithEndingTimeStamp(String fileNameBeforeTimeStamp,String timestampFormat, String path, String defaultFileName, String Var, String fileType) throws InterruptedException {


		String RenamedFileName = fileNameBeforeTimeStamp + setTimeFormat(timestampFormat) + fileType;
		//File to rename
		File oldFile = new File(path + defaultFileName);
		//File for rename
		File newFile = new File(path + RenamedFileName);
		ChangedFileName = newFile.getName();
		//Rename the specified file
		if (oldFile.renameTo(newFile)) {
			System.out.println("File renamed to new-file successfully");
			System.out.println(ChangedFileName);
		}
		Thread.sleep(2000);
	}

	public static void setRenamedFileNameWithTimeStamp1(String fileNameBeforeTimeStamp,String timestampFormat, String path, String defaultFileName, String fileType, String Var) throws InterruptedException {

		String RenamedFileName = fileNameBeforeTimeStamp + setTimeFormat(timestampFormat) + Var + fileType;
		//File to rename
		File oldFile = new File(path + defaultFileName);
		//File for rename
		File newFile = new File(path + RenamedFileName);
		ChangedFileName = newFile.getName();
		//Rename the specified file
		if (oldFile.renameTo(newFile)) {

		}
		Thread.sleep(2000);
	}
	public static void setRenamedFileDateTime(String fileNameBeforeTimeStamp, String path, String defaultFileName, String fileType, String Var) throws InterruptedException {


		String RenamedFileName = fileNameBeforeTimeStamp + Var + fileType;

		//File to rename
		File oldFile = new File(path + defaultFileName);
		//File for rename
		File newFile = new File(path + RenamedFileName);
		ChangedFileName = newFile.getName();
		//Rename the specified file
		if (oldFile.renameTo(newFile)) {
			//System.out.println("File renamed to new-file successfully");
			// System.out.println(ChangedFileName);
		}
		Thread.sleep(2000);
	}

	public static void setDuplicateFileNameInFolder(String path, String Default_FILE, String FileType) {
		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile = new File(path +
						"/" + file_array[i].getName());
				File newFile = new File(path + myfile);
				String ext1 = FilenameUtils.getExtension(newFile.toString());
				if (ext1.equalsIgnoreCase(FileType))
				{
					DEFAULT_FILE = newFile.getName();
					System.out.println("Duplicate file:"+ DEFAULT_FILE);
					break;
				}
			}

		}
	}

	public static void setInvalidHeaderFileNameInFolder(String path,String Default_FILE, String FileType,String To_replace, String Replace_value) throws IOException {
		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile = new File(path +
						"/" + file_array[i].getName());
				File newFile = new File(myfile.toString());
				BufferedReader br = new BufferedReader(new FileReader(newFile));
				String Line;

				while ((Line = br.readLine()) != null)
				{
					if (Line.contains(To_replace))
					{
						Line = Line.replace(To_replace, Replace_value);
						DEFAULT_FILE = newFile.getName();
						System.out.println("Updated:" + DEFAULT_FILE);

					}
					Lines.add(Line);

				}
				br.close();
				//setDefaultFileName(path,Default_FILE);
				File OutputFileCSV = new File(myfile.toString());
				FileWriter writer = new FileWriter(OutputFileCSV);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				for(String s : Lines) {
					bufferedWriter.write(s);
					bufferedWriter.write("\n");

				}
				bufferedWriter.close();

			}
		}

	}

	public static void ClearFile(String path) throws IOException {

		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++)
		{
			if (file_array[i].isFile())
			{
				File myfile = new File(path +
						"/" + file_array[i].getName());
				File newFile = new File(myfile.toString());

				BufferedReader br = new BufferedReader(new FileReader(newFile));

				// setDefaultFileName(pathMod, ChangedFileName);
				File OutputFileCSV = new File(String.valueOf(newFile));
				FileWriter writer = new FileWriter(OutputFileCSV);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.flush();
				bufferedWriter.close();
			}
		}
	}

	public static void UpdateFileHeaderandFooter(String path, String Upd_HDR, String Upd_Footer) throws IOException {
		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile = new File(path +
						"/" + file_array[i].getName());
				File newFile = new File(myfile.toString());
				BufferedReader br = new BufferedReader(new FileReader(newFile));

				Lines.add(Upd_HDR);
				Lines.add(Upd_Footer);
				br.close();

				File OutputFileCSV = new File(myfile.toString());
				FileWriter writer = new FileWriter(OutputFileCSV);

				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				for(String s : Lines) {

					bufferedWriter.write(s);
					bufferedWriter.write("\n");


				}
				bufferedWriter.close();
			}
		}

	}

	public static void UpdateFileFooter(String path, String Upd_Footer, String DEFAULT_FILE) throws IOException {
		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile = new File(path +
						"/" + file_array[i].getName());
				File newFile = new File(myfile.toString());
				BufferedReader br = new BufferedReader(new FileReader(newFile));
				String Line;

				while ((Line = br.readLine()) != null)
				{

					Lines.add(Upd_Footer);
					break;
				}

				br.close();
				//setDefaultFileName(path, DEFAULT_FILE);
				File OutputFileCSV = new File(myfile.toString());
				FileWriter writer = new FileWriter(OutputFileCSV);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				for(String s : Lines) {
					bufferedWriter.write(s);
					bufferedWriter.write("\n");


				}
				bufferedWriter.close();
			}
		}

	}

	public static void setEmptyFileNameInFolder(String path, String Default_FILE, String FileType) throws IOException {
		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile = new File(path +
						"/" + file_array[i].getName());
				File newFile = new File(myfile.toString());
				String ext1 = FilenameUtils.getExtension(newFile.toString());
				System.out.println(ext1);
				if (ext1.equalsIgnoreCase(FileType))
				{
					DEFAULT_FILE = newFile.getName();
					BufferedReader br = new BufferedReader(new FileReader(newFile));
					System.out.println(br);
					if (br.readLine()== null && newFile.length()==0) {
						System.out.println("File is empty:"  + DEFAULT_FILE);
						break;
					}
				}
			}

		}
	}

	public static void setDefaultFileNameInFolder(String path, String defaultFileName) {
		File myfolder = new File(path);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile = new File(path +
						"/" + file_array[i].getName());
				myfile.renameTo(new File(path +
						"/" + defaultFileName));

			}
		}
	}
	public static void uploadToStorageAcountContainer(String containerName,String connectStr,String localPath,String fileName) throws IOException {

		System.out.println("....Start Upload.....");
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().connectionString(connectStr).buildClient();
		BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(containerName);
		try
		{
			containerClient.createIfNotExists();
		}
		catch (Exception e)
		{

		}
		BlobClient blobClient = containerClient.getBlobClient(fileName);
		System.out.println("\nUploading to Blob storage as blob:\n\t" + blobClient.getBlobUrl());
		blobClient.uploadFromFile(localPath + fileName);
		System.out.println("Displaying uploaded file name :"+fileName);
		System.out.println("---------------------File Uploaded to Storage account Container Successful-----------------------------");
		//System.out.println(blobClient.getAccountInfo());
		//System.out.println(blobClient.downloadContent());
	}
	public static String getProperty(String KeyName)
	{
		Properties pro = null;
		File src = new File("src/main/resources/george.Properties");
		try
		{
			FileInputStream fis = new FileInputStream(src);
			pro = new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		String key= pro.getProperty(KeyName);
		return key;
	}

	public static void renameFile(String path,String previousName,String requiredName){
		File newFile = new File(path+ requiredName);
		File oldFile = new File(path+previousName);
		if(oldFile.renameTo(newFile )) {
			ChangedFileName =newFile.getName();
			log.info("File renamed to requiredName successful");
			//System.out.println(ChangedFileName);
		}
	}
	//public static void writeInFile(String filePath,String value) throws IOException {
	//    Path path = Paths.get(filePath);
	//   Files.writeString(path,value, StandardCharsets.UTF_8);
	//}
	public static void copyFileData(String CopyFrom,String Copyto) throws IOException {
		FileInputStream in = new FileInputStream(CopyFrom);
		FileOutputStream out = new FileOutputStream(Copyto);
		IOUtils.copy(in,out);
		in.close();
		out.close();
	}

	public static void setDefaultFileName(String path,String defaultFileName){
		File newFile = new File(path+ ChangedFileName);
		File oldFile = new File(path+defaultFileName);
		ChangedFileName =oldFile.getName();
		if(newFile.renameTo(oldFile )) {
			System.out.println("File renamed to oldfile successfully" + oldFile);
			System.out.println("File renamed to oldfile successfully" + newFile);
			System.out.println(ChangedFileName);
		}
	}

	public static void copyFiletoFolder(String path_Mod, String path_Csv) throws IOException {

		File myfolder = new File(path_Csv);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile_SRC = new File(path_Csv +
						"/" + file_array[i].getName());

				File myfile_TRG = new File(path_Mod +
						"/" + file_array[i].getName());

				FileUtils.copyFile(myfile_SRC, myfile_TRG);
				System.out.println("copying of file from Java program is completed");
			}
		}
	}

	public static void deleteFile(String path_Mod) throws IOException
	{
		File myfolder = new File(path_Mod);
		File[] file_array = myfolder.listFiles();
		for (int i = 0; i < file_array.length; i++) {
			if (file_array[i].isFile()) {

				File myfile_SRC = new File(path_Mod +
						"/" + file_array[i].getName());
				myfile_SRC.delete();

			}
		}
	}



	private static void delete(FileWriter writer) {
	}
	//------------------------------------------FileUtils---------------------------------------------------------------
	// public static String ChangedFileName = null;


	/*
	 * public static void setRenamedFileNameWithTimeStamp(String
	 * fileNameBeforeTimeStamp, String timestampFormat, String path, String
	 * defaultFileName, String fileNameAfterTimeStamp) throws InterruptedException {
	 * String RenamedFileName = fileNameBeforeTimeStamp +
	 * setTimeFormat(timestampFormat) + fileNameAfterTimeStamp; File oldFile = new
	 * File(path + defaultFileName); File newFile = new File(path +
	 * RenamedFileName); if (oldFile.renameTo(newFile)) { ChangedFileName =
	 * newFile.getName(); log.info("setRenamedFileNameWithTimeStamp() :: " +
	 * ChangedFileName); } Thread.sleep(2000); }
	 */

	/*
	 * public static void setDefaultFileNameInFolder(String path, String
	 * defaultFileName) { File myfolder = new File(path); File[] file_array =
	 * myfolder.listFiles(); for (int i = 0; i < file_array.length; i++) { if
	 * (file_array[i].isFile()) {
	 * 
	 * File myfile = new File(path + "/" + file_array[i].getName());
	 * myfile.renameTo(new File(path + "/" + defaultFileName)); } } }
	 */


	/*
	 * public static void renameFile(String path, String previousName, String
	 * requiredName) { File newFile = new File(path + requiredName); File oldFile =
	 * new File(path + previousName); if (oldFile.renameTo(newFile)) {
	 * ChangedFileName = newFile.getName(); log.info("renameFile() :: " +
	 * ChangedFileName); } }
	 */

	public static void writeInFile(String filePath, String value) throws IOException {
		Path path = Paths.get(filePath);
		Files.writeString(path, value, StandardCharsets.UTF_8);
	}

	/*
	 * public static void copyFileData(String CopyFrom, String Copyto) throws
	 * IOException { FileInputStream in = new FileInputStream(CopyFrom);
	 * FileOutputStream out = new FileOutputStream(Copyto); IOUtils.copy(in, out);
	 * in.close(); out.close(); }
	 */

	public static String getFileName(String path) {

		File folder = new File(path);
		File[] listOfFiles = folder.listFiles();
		String fileName = null;
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				fileName = listOfFiles[i].getName();
			}
		}
		log.info("getFileName()  :: " + fileName);
		return fileName;
	}
	//---------------------------------------------helperClass------------------------------------------------------------
	// private static JSONObject jsonObject;
	//private RequestSpecification requestSpecification;
	// public static List<List<List<String>>> logResponse;
	// private Response response;
	//final String LogAnalytics_BaseURl="https://api.loganalytics.io/v1/workspaces/";
	//final String LogAnalytics_BasePath="2ace1b78-fd69-4b72-a055-0e11f19e90d7/query";

	/*
	 * public static void logInAzureLogAnalyticsForGettingResult() throws
	 * InterruptedException, IOException, ParseException {
	 * RestAssured.baseURI=LogAnalytics_BaseURl; requestSpecification =
	 * given().basePath(LogAnalytics_BasePath);
	 * requestSpecification.header("Authorization","Bearer " +
	 * getLogAnalyicsAccessToken() ) .contentType(ContentType.JSON);
	 * 
	 * requestSpecification.body(jsonObject.toJSONString()); System.out.
	 * println("------------------------Waiting for log to be displayed in Log Analytics-------------------------------------------------"
	 * ); Thread.sleep(2000); //TODO need to find alternative of sleep this.response
	 * = requestSpecification.when().post(); this.response.then(); logResponse =
	 * this.response.jsonPath().getList("tables[0].rows"); if(logResponse == null) {
	 * System.out.println("Log == Null"); Thread.sleep(30000); this.response =
	 * requestSpecification.when().post(); this.response.then(); logResponse =
	 * this.response.jsonPath().getList("tables[0].rows"); } else
	 * if(logResponse.size()==0) Thread.sleep(70000); for (int i =1 ; i<20; i++) {
	 * if (logResponse.size()==0) { System.out.println("Count" + i); this.response =
	 * requestSpecification.when().post(); this.response.then(); logResponse =
	 * this.response.jsonPath().getList("tables[0].rows"); Thread.sleep(10000); }
	 * else break; } this.response = requestSpecification.when().post();
	 * this.response.then().assertThat().statusCode(200); logResponse =
	 * this.response.jsonPath().getList("tables[0].rows");
	 * System.out.println("Log Result: " + logResponse); Thread.sleep(5000); }
	 */
	public static String ReplaceStartEndDate(String Query, String startDate, String endDate, String operationName)
	{
		Query = Query.replace("startDate",startDate);
		Query = Query.replace("endDate", endDate);
		Query = Query.replace("functionName", operationName);
		return Query;
	}

	public static String ReplaceCorrelationId006(String Query, String operationName, String correlationId){
		Query = Query.replace("functionName", operationName);
		Query = Query.replace("correlationId", correlationId);
		return Query;
	}

	/*
	 * public static String getLogAnalyicsAccessToken(){ ReadConfig config; config =
	 * new ReadConfig(); RestAssured.baseURI =
	 * "https://login.microsoftonline.com/b63ee29f-aaa6-4d4e-8267-1d6dca9c0e43/oauth2/token";
	 * RequestSpecification https = RestAssured.given();
	 * https.multiPart("client_id", config.getLogAnalyticsClientId())
	 * .multiPart("client_secret",config.getLogAnalyticsClientSecret() )
	 * .multiPart("grant_type", config.getLogAnalyticsGrantType())
	 * .multiPart("resource", config.getLogAnalyticsResource());
	 * https.post().then().statusCode(200); Response response = https.post();
	 * ResponseBody body = response.getBody(); JsonPath jsnPath = body.jsonPath();
	 * String token = jsnPath.get("access_token"); //log.info("Token: " + token);
	 * return token; }
	 */
	public static String Genarate_RandonNumber() {
		return Integer.toString(1000000000 + new Random().nextInt(999999999));

	}

	public static void CreateQueryOfWorkFlowNameActionCallTimefunapp(String Path, String FunctionName, String filename) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		String Query ="";
		Object obj;
		obj = parser.parse(new FileReader(Path));
		jsonObject = (JSONObject)obj;
		Query = ReplaceWorkFlowNameActionCallTime1((String)  jsonObject.get("query"),FunctionName, filename);
		jsonObject.put("query", Query);
//		System.out.println("Query:  "+ Query);
	}

	public static String ReplaceWorkFlowNameActionCallTime1(String query, String FunctionName, String filename)
	{
		query = query.replace("filename",filename);
		query = query.replace("FunctionName", FunctionName);

		return query;
	}
	//---------------------------------------------JSON_Utils------------------------------------------------------------
	public static String[] ExtractKey(String Path)
	{
		String Slash="/";
		if(Path.startsWith(Slash)){
			log.info("path must not begin with a leading '/'");
		}
		String[] k1=Path.substring(0).split(Slash);
		//System.out.println(Arrays.deepToString(k1));
		return k1;
	}

	public static String addToJson(String Tag, Object value, String Path) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject obj=(JSONObject)parser.parse(new FileReader(Path));
		JSONObject obj1= AddValue(value,obj,ExtractKey(Tag));
		return obj1.toJSONString();
	}
	public static JSONObject Classobj;
	public static String AddToJason(String path, String Tag, Object value) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		if(path.isEmpty()){JSONObject obj10= AddValue(value, Classobj,ExtractKey(Tag));
		return obj10.toJSONString();}
		else{JSONObject obj2=(JSONObject)parser.parse(new FileReader(System.getProperty("user.dir") + path));
		JSONObject obj3= AddValue(value,obj2,ExtractKey(Tag));
		return obj3.toJSONString();}
	}
	public static void DeleteToJason(String path,String Tag) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		Classobj =(JSONObject)parser.parse(new FileReader(System.getProperty("user.dir") + path));
		DeleteValue(Classobj,ExtractKey(Tag));
	}
	public static String deleteInJason(String path,String Tag) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject Classobj1 =(JSONObject)parser.parse(new FileReader(System.getProperty("user.dir") + path));
		JSONObject Classobj2 =DeleteValue(Classobj1,ExtractKey(Tag));
		return Classobj2.toJSONString();
	}
	public static String deleteInJason(String path,String Tag, String Tag1) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject Classobj1 =(JSONObject)parser.parse(new FileReader(System.getProperty("user.dir") + path));
		JSONObject Classobj2 =DeleteValue(Classobj1,ExtractKey(Tag));
		JSONObject Classobj3 =DeleteValue(Classobj2,ExtractKey(Tag1));
		return Classobj3.toJSONString();
	}
	public static JSONObject AddValue(Object Value, JSONObject JsnObject , String[] Keys) throws IOException {
		int temp = 0;
		int temp3=0;
		String currentKey=Keys[0];
		JSONObject nestedjasonobjectval= new JSONObject();
		JSONObject Updatednestedvalue=new JSONObject();
		JSONArray Jarr=new JSONArray();
		if(Keys.length == 1)
		{
			JsnObject.put(currentKey,Value);
			return JsnObject;
		} else if (!JsnObject.containsKey(currentKey)){
			System.out.println(currentKey+"key not Found");
		}
		else
		{
			String IsJsonObject = new String();
			Object valueObj = JsnObject.get(currentKey);
			if (valueObj instanceof JSONObject ) {
				IsJsonObject="true";
			} else if (valueObj instanceof JSONArray) {
				IsJsonObject="false";
			}
			if ( IsJsonObject.equalsIgnoreCase("false")) {
				JSONArray jsonarry=(JSONArray)JsnObject.get(currentKey);

				nestedjasonobjectval = (JSONObject) jsonarry.get(0);
				temp=1;
			}
			else if( IsJsonObject.equalsIgnoreCase("true"))
			{
				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
				temp3=1;
			}
			else {
				System.out.println("Not able to identify type of object");
				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
			}
			String[] remainingKeys = Arrays.copyOfRange(Keys, 1, Keys.length);
			Updatednestedvalue = AddValue(Value, nestedjasonobjectval, remainingKeys);

		}
		if(temp==1)
		{
			if(temp3==1){
				JsnObject.put(currentKey, Updatednestedvalue);
				temp3=0;
			}else{
				Jarr.add(Updatednestedvalue);
				JsnObject.put(currentKey,Jarr);}
			if(Keys.length == 1) { temp=0;}
			return JsnObject;
		}
		else{
// JsnObject.remove(currentKey);
			JsnObject.put(currentKey, Updatednestedvalue);
			return JsnObject;}
	}
//	private static int temp=0;
//	public static JSONObject AddValue(Object Value, JSONObject JsnObject , String[] Keys) throws IOException {
//		String currentKey=Keys[0];
//		JSONObject nestedjasonobjectval= new JSONObject();
//		JSONObject Updatednestedvalue=new JSONObject();
//		JSONArray Jarr=new JSONArray();
//		if(Keys.length == 1)
//		{
//			JsnObject.put(currentKey,Value);
//			return JsnObject;
//		} else if (!JsnObject.containsKey(currentKey)){
//			System.out.println(currentKey+"key not Found");
//		}
//		else
//		{
//			String isjsnobj = new String();
//			Object valueObj = JsnObject.get(currentKey);
//			if (valueObj instanceof JSONObject) {
//				//System.out.println("jsnobj");
//				isjsnobj="true";
//			} else if (valueObj instanceof JSONArray) {
//				// System.out.println("not jsnobj");
//				isjsnobj="false";
//			}
//			if ( isjsnobj.equalsIgnoreCase("false")) {
//				JSONArray jsonarry=(JSONArray)JsnObject.get(currentKey);
//				nestedjasonobjectval = (JSONObject) jsonarry.get(0);
//				temp=1;
//			}
//			else if( isjsnobj.equalsIgnoreCase("true"))
//			{
//				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
//			}
//			else {
//				// System.out.println("Not able to identify type of object");
//				log.error("Not able to identify type of object (is jsonobjrct or json array)");
//				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
//			}
//			String[] remainingKeys = Arrays.copyOfRange(Keys, 1, Keys.length);
//			Updatednestedvalue = AddValue(Value, nestedjasonobjectval, remainingKeys);
//
//		}
//		if(temp==1)
//		{
//			Jarr.add(Updatednestedvalue);
//			JsnObject.put(currentKey,Jarr);
//			if(Keys.length == 1) { temp=0;}
//			return JsnObject;
//		}
//		else{
//			JsnObject.put(currentKey, Updatednestedvalue);
//			return JsnObject;}
//	}

//	private static int temp1=0;
//	public static JSONObject DeleteValue(JSONObject JsnObject, String[] Keys) throws IOException {
//		String currentKey=Keys[0];
//		JSONObject nestedjasonobjectval= new JSONObject();
//		JSONObject Updatednestedvalue=new JSONObject();
//		JSONArray Jarr=new JSONArray();
//		if(Keys.length == 1)
//		{
//			JsnObject.remove(currentKey);
//			return JsnObject;
//		} else if (!JsnObject.containsKey(currentKey)){
//			System.out.println(currentKey+" key not Found");
//		}
//		else{
//			String IsJsonObject = new String();
//			Object valueObj = JsnObject.get(currentKey);
//			if (valueObj instanceof JSONObject) {
//				IsJsonObject="true";
//			} else if (valueObj instanceof JSONArray) {
//				IsJsonObject="false";
//			}
//			if ( IsJsonObject.equalsIgnoreCase("false")) {
//				JSONArray jsonarry=(JSONArray)JsnObject.get(currentKey);
//				nestedjasonobjectval = (JSONObject) jsonarry.get(0);
//				temp1=1;
//			}
//			else if( IsJsonObject.equalsIgnoreCase("true"))
//			{
//				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
//			}
//			else {
//				System.out.println("Not able to identify type of object");
//				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
//			}
//			String[] remainingKeys = Arrays.copyOfRange(Keys, 1, Keys.length);
//			Updatednestedvalue = DeleteValue( nestedjasonobjectval, remainingKeys);
//
//		}
//		if(temp1==1)
//		{
//			Jarr.add(Updatednestedvalue);
//			JsnObject.put(currentKey,Jarr);
//			if(Keys.length == 1) { temp1=0;}
//			return JsnObject;
//		}
//		else{
//			// JsnObject.remove(currentKey);
//			JsnObject.put(currentKey, Updatednestedvalue);
//			return JsnObject;}
//	}
	public static JSONObject DeleteValue(JSONObject JsnObject, String[] Keys) throws IOException {
		int temp1=0;
		int temp2=0;
		String currentKey=Keys[0];
		JSONObject nestedjasonobjectval= new JSONObject();
		JSONObject Updatednestedvalue=new JSONObject();
		JSONArray Jarr=new JSONArray();
		if(Keys.length == 1)
		{
			JsnObject.remove(currentKey);
			return JsnObject;
		} else if (!JsnObject.containsKey(currentKey)){
			System.out.println(currentKey+" key not Found");
		}
		else{
			String IsJsonObject = new String();
			Object valueObj = JsnObject.get(currentKey);
//|| StringUtils.firstNonBlank(valueObj.toString()).equals("{")
			if (valueObj instanceof JSONObject ) {
				IsJsonObject="true";
			} else if (valueObj instanceof JSONArray) {
				IsJsonObject="false";
			}
			if ( IsJsonObject.equalsIgnoreCase("false")) {
				JSONArray jsonarry=(JSONArray)JsnObject.get(currentKey);
				nestedjasonobjectval = (JSONObject) jsonarry.get(0);
				temp1=1;
			}
			else if( IsJsonObject.equalsIgnoreCase("true"))
			{
				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
				temp2=1;
			}
			else {
				System.out.println("Not able to identify type of object");
				nestedjasonobjectval = (JSONObject) JsnObject.get(currentKey);
			}
			String[] remainingKeys = Arrays.copyOfRange(Keys, 1, Keys.length);
			Updatednestedvalue = DeleteValue( nestedjasonobjectval, remainingKeys);

		}
		if(temp1==1)
		{
			if(temp2==1){
				JsnObject.put(currentKey, Updatednestedvalue);
				temp2=0;
			}else{
				Jarr.add(Updatednestedvalue);
				JsnObject.put(currentKey,Jarr);}
			if(Keys.length == 1) { temp1=0;}
			return JsnObject;
		}
		else{
// JsnObject.remove(currentKey);
			JsnObject.put(currentKey, Updatednestedvalue);
			return JsnObject;}
	}


	public static void printingjason()
	{
		ObjectMapper mapper = new ObjectMapper();
		File f1=new File(System.getProperty("user.dir") + "/src/main/Grocery/JustEat.json");
		try {
			Map<String, Object> map = mapper.readValue(f1, new TypeReference<Map<String, Object>>(){ });
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				System.out.println("key=" + entry.getKey() + ", value=" + entry.getValue());
			}
			System.out.println(map.get("driver"));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
	}
	public static void printingjason1() throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject obj=(JSONObject)parser.parse(new FileReader(System.getProperty("user.dir") + "/src/main/Grocery/JustEat.json"));
		try{
			System.out.println(obj.get("id"));
			System.out.println(obj.get("location"));
			System.out.println(obj.get("location.id"));
			System.out.println(obj.get("driver"));
			System.out.println(obj.get("first_name"));
			System.out.println(obj.get("items"));
			System.out.println(obj.get("name"));}
		catch(Exception e){
			System.out.println(e);

		}
	}

	public static JsonObject convertToJsonObject(Object payload) {
		GsonBuilder builder = new GsonBuilder();
		return (JsonObject) builder.setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_DASHES).
				create().toJsonTree(payload);
	}
	public static String formatJson(Object jsonObject){
		Gson gson=new GsonBuilder().setPrettyPrinting().create();
		return (gson.toJson(jsonObject));
	}

	private static final String DELIVEROO_JSON_PATH = "/src/test/resources/testData/deliveroo.json";
	public static String addToJasonDeliveroo(String Tag, String value) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject obj=(JSONObject)parser.parse(new FileReader( System.getProperty("user.dir") + DELIVEROO_JSON_PATH));
		System.out.println("Before modifying: \n" + obj + "------------------------------------------------");
		JSONObject obj1= AddValue(null,obj,ExtractKey(Tag));
		System.out.println(obj1.toJSONString());
		return obj1.toJSONString();
	}

	//-----------------------------------------------TimeUtils----------------------------------------------------------
	// public static DateTimeFormatter dtf;
	//public static LocalDateTime now;
	//public static String DateTimeFormater;
	/*    public static String setTimeFormat(String timestampFormat) {
        dtf = DateTimeFormatter.ofPattern(timestampFormat);
        now = LocalDateTime.now();
        DateTimeFormater = dtf.format(now);
      //  System.out.println(DateTimeFormater);
        return DateTimeFormater;
    }*/
	public static String addTime(String Time, Long AddTime, String TimePattern, ChronoUnit ChronoUnitDotTimeUnit) {
		dtf = DateTimeFormatter.ofPattern(TimePattern);
		now = LocalDateTime.parse(Time, dtf);
		String TimeAfterAddition = now.plus(AddTime, ChronoUnitDotTimeUnit).format(dtf);
		return TimeAfterAddition;
	}


	//--------------------------------------------utilityClass-------------------------------------------------------------
	private static final String ALGORITHM = "AES";
	private static final byte[] KEY = "AHDi7u38hHDIUgfk".getBytes();

	//Method to encrypt any string value. It takes the String to be encrypted as parameter
	public static String encrypt(String stringToEncrypt) throws Exception{
		Key key = generateKey();
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE,key);
		byte[] encValue = cipher.doFinal(stringToEncrypt.getBytes());
		return Base64.getEncoder().encodeToString(encValue);
	}

	//Method to decrypt any string value. It takes the String to be decrypted as parameter
	public static String decrypt(String encyptedValue) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Key key = generateKey();
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] decryptedValue = cipher.doFinal(Base64.getDecoder().decode(encyptedValue));
		return new String(decryptedValue);

	}

	private static Key generateKey(){
		return new SecretKeySpec(KEY, ALGORITHM);
	}

	//Method to get any value of a key from JSON provided the path to the key and the JSON file location as parameters
	public static Object getValue(String keyPath, FileReader fileReader) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(fileReader);
		String[] keys = keyPath.split("/");
		Object value = jsonObject;
		for (String key : keys) {
			if (value instanceof JSONArray) {
				JSONArray array = (JSONArray) value;
				for (Object obj : array) {
					if (obj instanceof JSONObject) {
						JSONObject json = (JSONObject) obj;
						if (json.containsKey(key)) {
							value = json.get(key);
							break;
						}
					}
				}
			} else {
				value = ((JSONObject) value).get(key);
			}
		}
		System.out.println("value :" + value);
		return value;
	}


	//Method to check if a file exist in SFTP location provided fileName in parameter
	public static boolean checkFileSftp(String fileName) throws JSchException, FileNotFoundException {
		String hostName = "mft-test.asda.uk";
		int port = 22;
		String userName = "hemavathi.ramanujam@asda.uk";
		String password = "ChangeMe1234";
		String localFile = "src/test/resources/sftp/DSV964864-Acknowledgement.csv";
		String remoteFileLocation = "/active/grp_dsv_melrose/outbound/G-OMS-0018";

		boolean checkFileExistFlag = false;
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(userName, hostName, port);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftp = (ChannelSftp) channel;
			//sftp.put(localFile, remoteFileLocation);
			Vector<ChannelSftp.LsEntry> list = sftp.ls(remoteFileLocation);
			for(ChannelSftp.LsEntry entry: list){
				if(entry.getFilename().equals(fileName)){
					System.out.println("--------------here--------------");
					checkFileExistFlag = true;
					break;
				}
			}
			sftp.exit();
			session.disconnect();


		} catch (SftpException e) {
			e.printStackTrace();
		}
		return checkFileExistFlag;
	}

	public static boolean checkFileSftp(String fileName , String remoteFileLocation) throws JSchException, FileNotFoundException {
		String hostName = "mft-test.asda.uk";
		int port = 22;
		String userName = "hemavathi.ramanujam@asda.uk";
		String password = "ChangeMe1234";
		String localFile = "src/test/resources/sftp/DSV964864-Acknowledgement.csv";


		boolean checkFileExistFlag = false;
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(userName, hostName, port);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftp = (ChannelSftp) channel;
			//sftp.put(localFile, remoteFileLocation);
			Vector<ChannelSftp.LsEntry> list = sftp.ls(remoteFileLocation);
			for(ChannelSftp.LsEntry entry: list){
				if(entry.getFilename().equals(fileName)){
					checkFileExistFlag = true;
					break;
				}
			}
			sftp.exit();
			session.disconnect();


		} catch (SftpException e) {
			e.printStackTrace();
		}
		return checkFileExistFlag;
	}

	public static void downloadFile(String fileName, String remoteFileLocation){
		String hostName = "mft-test.asda.uk";
		int port = 22;
		String userName = "hemavathi.ramanujam@asda.uk";
		String password = "ChangeMe1234";
		String localFile = "src/test/resources/sftp/DSV964864-Acknowledgement.csv";
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(userName, hostName, port);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftp = (ChannelSftp) channel;
			//sftp.put(localFile, remoteFileLocation);
			OutputStream os = new FileOutputStream("src/test/resources/testData/"+fileName);
			((ChannelSftp) channel).get(remoteFileLocation+"/"+fileName, os);
			sftp.exit();
			session.disconnect();


		} catch (SftpException e) {
			e.printStackTrace();
		} catch (JSchException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static void downloadCsvFile(String fileName){
		String hostName = "mft-test.asda.uk";
		int port = 22;
		String userName = "hemavathi.ramanujam@asda.uk";
		String password = "ChangeMe1234";
		String localFile = "src/test/resources/sftp/DSV964864-Acknowledgement.csv";
		String remoteFileLocation = "/active/grp_dsv_melrose/outbound/G-OMS-0018";
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(userName, hostName, port);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftp = (ChannelSftp) channel;
			//sftp.put(localFile, remoteFileLocation);
			OutputStream os = new FileOutputStream("src/test/resources/testData/"+fileName);
			((ChannelSftp) channel).get(remoteFileLocation+"/"+fileName, os);
			sftp.exit();
			session.disconnect();


		} catch (SftpException e) {
			e.printStackTrace();
		} catch (JSchException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static List<String> getAllKeysAndValues(Object json){
		List<String> inputJsonList = new ArrayList<>();;
		if(json instanceof JSONObject){
			JSONObject jsonObject = (JSONObject) json;
			for(Object key: ((JSONObject) json).keySet()){
				if(jsonObject.get(key) instanceof JSONObject){
					inputJsonList.addAll(getAllKeysAndValues(jsonObject.get(key)));
				}else if (jsonObject.get(key) instanceof JSONArray){
					JSONArray jsonArray = (JSONArray) jsonObject.get(key);
					for(Object arrayElement:jsonArray){
						if(arrayElement instanceof JSONObject){
							inputJsonList.addAll(getAllKeysAndValues(arrayElement));
						}else{
							inputJsonList.add(key+":"+arrayElement);
						}
					}
				}else{
					inputJsonList.add(key+":"+jsonObject.get(key));
				}
			}
		}
		return inputJsonList;
	}
	public static List<String> mappingSheet() {
		List<String> mappingList = new ArrayList<>();
		try{
			FileInputStream inputStream = new FileInputStream(new File("src/test/resources/mappingSheets/PoDsvCsvXmlConversionMappingSheet.xlsx"));
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = firstSheet.iterator();
			for(int i = 0; i<3;i++){
				iterator.next();
			}
			Map<String, Integer> columnIndices = new HashMap<>();
			Row fourthRow = iterator.next();
			Iterator<Cell> cellIterator = fourthRow.cellIterator();
			while(cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				String columnName = cell.getStringCellValue();
				if (columnName.equals("Field Name")) {
					columnIndices.put("Field Name", cell.getColumnIndex());
				} else if (columnName.equals("List any Mappings / Transformation Rules / Enrichment")) {
					columnIndices.put("List any Mappings / Transformation Rules / Enrichment", cell.getColumnIndex());

				} else if (columnName.equals("Target system field name (I.e CountBasketItems)")) {
					columnIndices.put("Target system field name (I.e CountBasketItems)", cell.getColumnIndex());
				}
			}
			while (iterator.hasNext()){
				Row nextRow = iterator.next();
				String fieldName = nextRow.getCell(columnIndices.get("Field Name")).getStringCellValue();
				String listMapping = nextRow.getCell(columnIndices.get("List any Mappings / Transformation Rules / Enrichment")).getStringCellValue();
				String targetFieldName = nextRow.getCell(columnIndices.get("Target system field name (I.e CountBasketItems)")).getStringCellValue();
				if(listMapping.equals("Mapped")){
					mappingList.add(fieldName+":"+targetFieldName);
				}

			}

			inputStream.close();
			//System.out.println("mapping list :"+mappingList);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mappingList;
	}

	public static String getXMLvalue(String xPath, String XMLPath ) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		String value = null;
		File file = new File(System.getProperty("user.dir") + "/" + XMLPath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder =domFactory.newDocumentBuilder();
		Document doc = builder.parse(file);
		XPath xpath = XPathFactory.newInstance().newXPath();
		Node node = (Node) xpath.evaluate(xPath, doc, XPathConstants.NODE);

		if(node!= null){
			if(node.getNodeType()==Node.ATTRIBUTE_NODE){
				value  = node.getNodeValue();
			}else{
				value = node.getTextContent();
			}
		}else {
			System.out.println("no match");
		}
		return value;

	}

	private static final String connectionString = "Endpoint=sb://sb-etsint-test-uks-01.servicebus.windows.net/;SharedAccessKeyName=george-oms0006;SharedAccessKey=+FX7pHKUXHhU2/+PkbhyyiX+8csiwnVDX+ASbAXag34=";
	private static final String subscriptionName = "sbs-inventoryatp-erds";
	public static String topicName ="sbt-george-inventoryatppublish-inbound";
	public static String sbsMessages = null;
	public static String getSBmessages(Long sequenceNumber) throws InterruptedException {
//        String baseURI = "https://sb-etsint-test-uks-01.servicebus.windows.net";
//        String subscriptionPath = "sbt-george-inventoryatppublish-inbound/subscriptions/sbs-inventoryatp-erds";
//        String sasKeyName = "george-oms0006";
//        String sasaKeyValue = "Y30Re5UgAu1YmxjyIoZWQK44a7d4Wrm1d+ASbNSLgMI=";
//        String sasToken = helperUtility.GetSASToken(baseURI + "/" + subscriptionPath, sasKeyName, sasaKeyValue);
//        System.out.println(sasToken);
//        RequestSpecification requestSpecification = RestAssured.given();
//        requestSpecification.header("Authorization", sasToken);
//        requestSpecification.header("Content-Type", "application/atom+xml;type=entry;charset=utf-8");
//        requestSpecification.header("x-ms-version", "2020-09-01");
//
//        Response response = requestSpecification.get(baseURI+"/"+subscriptionPath+"/messages?api-version=2020-09");
//        response.then().assertThat().statusCode(200);
//        String responseBody = response.getBody().asString();
//        System.out.println(responseBody);
//    }

		CountDownLatch countDownLatch = new CountDownLatch(1);
		ServiceBusReceiverAsyncClient receiver = new ServiceBusClientBuilder()
				.connectionString(connectionString)
				.receiver()
				.topicName(topicName)
				.subscriptionName(subscriptionName)
				.receiveMode(ServiceBusReceiveMode.PEEK_LOCK)
				.buildAsyncClient();

		receiver.peekMessage(sequenceNumber).subscribe(
				messages -> {
					sbsMessages = messages.getBody().toString();
				},
				error -> System.out.println("Error occurred while receiving :"+error),
				()-> {
					System.out.println("complete");
				});

		countDownLatch.await(10, TimeUnit.SECONDS);

		receiver.close();
		return sbsMessages;

	}

	public static String GetSASToken(String resourceUri, String keyName, String key)
	{
		long epoch = System.currentTimeMillis()/1000L;
		int week = 60*60*24*7;
		String expiry = Long.toString(epoch + week);

		String sasToken = null;
		try {
			String stringToSign = URLEncoder.encode(resourceUri, "UTF-8") + "\n" + expiry;
			String signature = getHMAC256(key, stringToSign);
			sasToken = "SharedAccessSignature sr=" + URLEncoder.encode(resourceUri, "UTF-8") +"&sig=" +
					URLEncoder.encode(signature, "UTF-8") + "&se=" + expiry + "&skn=" + keyName;
		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();
		}

		return sasToken;
	}

	public static String getHMAC256(String key, String input) {
		Mac sha256_HMAC = null;
		String hash = null;
		try {
			sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(key.getBytes(), "HmacSHA256");
			sha256_HMAC.init(secret_key);
			Base64.Encoder encoder = Base64.getEncoder();

			hash = new String(encoder.encode(sha256_HMAC.doFinal(input.getBytes("UTF-8"))));

		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return hash;
	}


	public static List<String> csvOutputFile(String fileName) {
		List<String> outputCsvList = new ArrayList<>();
		String line = "";
		String csvSplitBy = ",";
		try (BufferedReader br = new BufferedReader(new FileReader("src/test/resources/testData/" + fileName))) {
			String[] keys = br.readLine().split(csvSplitBy);
			String[] values = br.readLine().split(csvSplitBy);

			for (int i = 0; i < keys.length; i++) {
				String key = keys[i].replaceAll("\"", "").trim();
				String value = values[i].replaceAll("\"", "").trim();
				outputCsvList.add(key + ":" + value);
			}

			//System.out.println("output list :"+outputCsvList);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return outputCsvList;
	}

	public static void ModifyXMLvalue(String Path, String XMLPath ,String Value) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		File file = new File(System.getProperty("user.dir") +"/"+ XMLPath );
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file.getAbsolutePath());
		XPath xpath = XPathFactory.newInstance().newXPath();
		String xPathStr = Path + "/text()";
		Node node = ((NodeList) xpath.compile(xPathStr).evaluate(doc, XPathConstants.NODESET)).item(0);
		node.setNodeValue(Value);
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(System.getProperty("user.dir") + "/src/test/resources/testData/ModifiedValue_XML.xml"));
	}

	public static void deleteXMLtag(String Path, String XMLPath) throws ParserConfigurationException, IOException, SAXException, TransformerException, XPathExpressionException {
		File file = new File(System.getProperty("user.dir") + XMLPath );
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file.getAbsolutePath());
		XPath xpath = XPathFactory.newInstance().newXPath();
		String xPathStr = Path + "/text()";
		Node node = (Node) xpath.evaluate(xPathStr,doc,XPathConstants.NODE);
		node.getParentNode().getParentNode().removeChild(node.getParentNode());
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File("src/test/resources/testData/deletedXml.xml"));
		transformer.transform(source,result);
	}
	//----------------------------------------------Xml_Utils-----------------------------------------------------------
	public static void modifyXmlNodeKeyValueByIndex(String OldFilePath, String NewFilePath, String NodeName, int NodeIndex, String NodeKeyName, Object oldValue, Object newValue) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		File file = new File(OldFilePath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file);
		NodeList listOfNode = doc.getElementsByTagName(NodeName);
		for (int i = 0; i < listOfNode.getLength(); i++) {
			Node NodeReference = listOfNode.item(NodeIndex);
			if (NodeReference.getNodeType() == Node.ELEMENT_NODE) {
				String NodeKey = NodeReference.getAttributes().getNamedItem(NodeKeyName).getTextContent();
				if (oldValue.equals(NodeKey.trim())) {
					NodeReference.getAttributes().getNamedItem(NodeKeyName).setTextContent(String.valueOf(newValue));
				}
			}
		}
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
	}

	public static void ModifyXmlNodeValue(String OldFilePath, String NewFilePath, String NodePath, String Value) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		File file = new File(OldFilePath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file);
		XPath xpath = XPathFactory.newInstance().newXPath();
		String xPathStr = NodePath + "/text()";
		Node node = ((NodeList) xpath.compile(xPathStr).evaluate(doc, XPathConstants.NODESET)).item(0);
		node.setNodeValue(Value);
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
	}

	public static void modifyXmlRemoveNodeKeyNameByIndexAndValue(String OldFilePath, String NewFilePath, String NodeName, int NodeIndex, String NodeKeyName, Object NodekeyValue) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		try {
			File file = new File(OldFilePath);
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			Document doc = domFactory.newDocumentBuilder().parse(file);
			NodeList listOfNode = doc.getElementsByTagName(NodeName);
			for (int i = 0; i < listOfNode.getLength(); i++) {
				Node NodeReference = listOfNode.item(NodeIndex);
				if (NodeReference.getNodeType() == Node.ELEMENT_NODE) {
					String NodeKey = NodeReference.getAttributes().getNamedItem(NodeKeyName).getTextContent();
					if (NodekeyValue.equals(NodeKey.trim())) {
						NodeReference.getAttributes().removeNamedItem(NodeKeyName);
					}
				}
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
			}
		} catch (Exception e) {}
	}
	public static void modifyXmlNodeValueByIndex(String OldFilePath, String NewFilePath, String NodeName, int NodeIndex, String nodeValue) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		File file = new File(OldFilePath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file);
		NodeList listOfNode = doc.getElementsByTagName(NodeName);
		for (int i = 0; i < listOfNode.getLength(); i++) {
			Node NodeReference = listOfNode.item(NodeIndex);
			NodeReference.setTextContent(nodeValue);
		}
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
	}
	public static void modifyXmlRemoveChildNode(String Filepath, String NewFilePath, String ParentNodeName,int ParentNodeIndex, String ChildNodeName) throws TransformerException, ParserConfigurationException, IOException, SAXException {
		File inputfile = new File(Filepath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = domFactory.newDocumentBuilder();
		Document doc = db.parse(inputfile);
		NodeList listOfNode = doc.getElementsByTagName(ParentNodeName);
		for (int i = 0; i < listOfNode.getLength(); i++) {
			Node node = listOfNode.item(ParentNodeIndex);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				NodeList childNodes = node.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Node item = childNodes.item(j);
					if (item.getNodeType() == Node.ELEMENT_NODE) {
						if (ChildNodeName.equalsIgnoreCase(item.getNodeName())) {
							node.removeChild(item);
						}
					}
				}
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
		}
	}
	public static void modifyXmlNodeValueByPreviousValue(String OldFilePath, String NewFilePath, String NodeName,String oldValue, String newValue) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		File file = new File(OldFilePath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file);
		NodeList listOfNode = doc.getElementsByTagName(NodeName);
		for (int i = 0; i < listOfNode.getLength(); i++) {
			Node NodeReference = listOfNode.item(i);
			if (NodeReference.getTextContent().equalsIgnoreCase(oldValue)) {
				NodeReference.setTextContent(newValue);
			}
		}
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
	}
	public static void modifyXmlNodeValueByNodeKeyValue(String OldFilePath, String NewFilePath, String NodeName,String NodeKeyName,String NodeKeyValue, String newNodeValue) throws ParserConfigurationException, IOException, SAXException, TransformerException {
		File file = new File(OldFilePath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file);
		NodeList listOfNode = doc.getElementsByTagName(NodeName);
		for (int i = 0; i < listOfNode.getLength(); i++) {
			Node NodeReference = listOfNode.item(i);
			if (NodeReference.getNodeType() == Node.ELEMENT_NODE) {
				String NodeKey = NodeReference.getAttributes().getNamedItem(NodeKeyName).getTextContent();
				if (NodeKeyValue.equals(NodeKey.trim())) {
					NodeReference.setTextContent(newNodeValue);
				}
			}
		}
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(NewFilePath));
	}

	/*
	*description:- Added to utils by Abhishek Kumar
	*/
	public void WriteXmlFileUsingXpathFilepath(String InputFilepath,String OutPutFile,String[] NodePaths, String[] Tags,String[] value)
	{
		try {File input= new File(InputFilepath);
			//System.out.println(input.getName());
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder=factory.newDocumentBuilder();
			Document doc=builder.parse(input);
			doc.getDocumentElement().normalize();
			XPath xPath = XPathFactory.newInstance().newXPath();
			for(int b=0;  b<NodePaths.length; b++)
			{
				NodeList nodelist = (NodeList) xPath.compile(NodePaths[b]).evaluate(doc, XPathConstants.NODESET);
				Node node1 = nodelist.item(0);
				if (node1.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node1;
					if(eElement.hasAttribute(Tags[b])) {
						if(value[b].equalsIgnoreCase("Remove")){
							eElement.removeAttribute(Tags[b]);
						}else{
							eElement.setAttribute(Tags[b], value[b]);}
					}else {
						if(value[b].equalsIgnoreCase("Remove")){

						}else{
							eElement.getElementsByTagName(Tags[b]).item(0).setTextContent(value[b]);}
					}
				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.transform(new DOMSource(doc), new StreamResult(OutPutFile));

		} catch (ParserConfigurationException | IOException | SAXException | XPathExpressionException | TransformerException e) {
			log.error("Getting error in write XML "+e.getMessage());
		}
	}
	//-------------------------------------------SftpUtils--------------------------------------------------------------
	 private static final int SESSION_TIMEOUT = 10000;
	    private static final int CHANNEL_TIMEOUT = 5000;
	    private static Session session;
	    private static JSch jSch = new JSch();
	    private static ChannelSftp channelSftp;

	    public static void setKnownHost(String file) throws JSchException {
	        jSch.setKnownHosts(file);
	    }
	    public static void getSession(String hostNameOrIP) {
	        try {
	            jSch.getSession(hostNameOrIP);
	        }catch (Exception e){}
	    }
	    public static void getSession(String userName , String hostNameOrIP, String port) {
	       try {
	           session = jSch.getSession(userName , hostNameOrIP, Integer.parseInt(port));
	       }catch (Exception e){}
	    }
	    public static void getSession(String userName, String hostNameOrIP) {
	       try {
	           jSch.getSession(userName, hostNameOrIP);
	       }catch (Exception e){}
	    }
	    public static void authUsingPrivateKey(String privateKey) throws JSchException {
	        jSch.addIdentity(privateKey);
	    }
	    public static void disableHostKeyCheck() {
	        session.setConfig("StrictHostKeyChecking", "no");
	    }
	    public static void authUsingPassword(String password) {
	        session.setPassword(password);
	    }
	    public static void connectToSftp() throws JSchException {
	        session.connect(SESSION_TIMEOUT);
	        Channel sftp = session.openChannel("sftp");
	        sftp.connect(CHANNEL_TIMEOUT);
	        channelSftp = (ChannelSftp) sftp;
	    }
	    public static void uploadFileInSftp(String localFile, String sftpFile) throws SftpException {
	        channelSftp.put(localFile, sftpFile);
	        channelSftp.exit();
	        if (session != null) {
	            session.disconnect();
	        }
	    }
	    public static void downloadFileFromSftp(String localFile, String sftpFile) throws SftpException {
	        channelSftp.get(sftpFile, localFile);
	        channelSftp.exit();
	        if (session != null) {
	            session.disconnect();
	        }
	    }
		/*
		* Method Name:-SFTPUpload
		* Parameter:- User Name, Password, File Name, Local File path, Remote Location path
		* Description:- method is created for file uploading to SFTP folder using JSCH class for FDD 18a.
		* Created by:- Abhishek Kumar , copied on Date-23-03-2023 from old projectlog
		*/
		private static String hostName = "mftweb-test.asda.uk";
		private static int port = 22;
		public static void SFTPUpload(String userName, String password,String FileName,String localFile,String remoteFileLocation) {
		localFile=localFile+FileName;
		remoteFileLocation=remoteFileLocation+FileName;
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(userName, hostName, port);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftp = (ChannelSftp) channel;
			sftp.put(localFile, remoteFileLocation);
			log.info("File "+FileName+" Uploaded to SFTP");
			sftp.exit();
			session.disconnect();
		} catch (SftpException | JSchException e) {
			e.printStackTrace();
			log.error("Exception happened => "+e.getMessage());
		}
		}
//	    public void checkFileInSftp(){
//	        Vector<ChannelSftp.LsEntry entry :list>
	//
//	    }
//	    public void connectToSftpLocation(String userName, String method, String localFile, String remoteFile ) throws JSchException, SftpException {
//	        session = jSch.getSession(userName , "mftweb-test.asda.uk", 22);
//	        session.setPassword(userName);
//	        disableHostKeyCheck();
//	        connectToSftp();
//	        switch (method){
//	            case "upload":
//	                uploadFileInSftp(localFile, remoteFile);
//	            case "doenload":
//	                downloadFileFromSftp(localFile, remoteFile);
//	            case "check":
	//
//	        }
	//


	//---------------------------------------------------------------------------------------------------------

	//---------------------------------------------------------------------------------------------------------

	public static Object getValueString(String keyPath, String fileReader) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(fileReader);
		String[] keys = keyPath.split("/");
		Object value = jsonObject;
		for (String key : keys) {
			if (value instanceof JSONArray) {
				JSONArray array = (JSONArray) value;
				for (Object obj : array) {
					if (obj instanceof JSONObject) {
						JSONObject json = (JSONObject) obj;
						if (json.containsKey(key)) {
							value = json.get(key);
							break;
						}
					}
				}
			} else {
				value = ((JSONObject) value).get(key);
			}
		}
		System.out.println("value :" + value);
		return value;
	}
	public void modifyXmlAttributeID( String FilePath, String NodeName, String attributeID, String nodeValue) throws TransformerException, XPathExpressionException, ParserConfigurationException, IOException, SAXException {
		File file = new File(FilePath);
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		Document doc = domFactory.newDocumentBuilder().parse(file);
		NodeList listOfNode = doc.getElementsByTagName(NodeName);
		for (int i = 0; i < listOfNode.getLength(); i++) {
			Node NodeReference = listOfNode.item(i);
			if(NodeReference.getAttributes().getNamedItem("attribute-id").getTextContent().equalsIgnoreCase(attributeID)){
				NodeReference.setTextContent(nodeValue);

			}
		}
		System.out.println("XML attribute changed");
		}


}
