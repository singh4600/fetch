package utilClass;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ReadConfig {
	
	private static final Logger log = LogManager.getLogger(ReadConfig.class.getName());
	
    Properties pro;
    public ReadConfig()
    {
        File src = new File("src/main/resources/george.Properties");
        try
        {
            FileInputStream fis = new FileInputStream(src);
            pro = new Properties();
            pro.load(fis);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public String getValue(String Key){
        String value=pro.getProperty(Key);
        return value;
    }
    
    
    public String getPoDsvXmlConversion0018BaseURI(){
        String url = pro.getProperty("PoDsvXmlCsvConversion-0018_baseURI");
        return url;
    }
    public String getPoDsvXmlConversion0018ClientId(){
        String clientId = pro.getProperty("PoDsvXmlCsvConversion-0018_clientId");
        return clientId;
    }
    public String getPoDsvXmlConversion0018ClientSecret(){
        String clientSecret = pro.getProperty("PoDsvXmlCsvConversion-0018_ClientSecret");
        return clientSecret;
    }
    public String getPoDsvXmlConversion0018GrantType(){
        String grantType = pro.getProperty("PoDsvXmlCsvConversion-0018_GrantType");
        return grantType;
    }
    public String getPoDsvXmlConversion0018RedirectUrl(){
        String redirectUrl = pro.getProperty("PoDsvXmlCsvConversion-0018_redirectURL");
        return redirectUrl;
    }
    public String getPoDsvXmlConversion0018Scope(){
        String scope = pro.getProperty("PoDsvXmlCsvConversion-0018_Scope");
        return scope;
    }
    public String getPoDsvXmlConversion0018TestUrl(){
        String testUrl = pro.getProperty("PoDsvXmlCsvConversion-0018_TestURL");
        return testUrl;
    }
    public String getPoDsvXmlConversion0018SubscriptionKey(){
        String subscriptionKey = pro.getProperty("Ocp-Apim-Subscription-Key");
        return subscriptionKey;
    }
    public String getLogAnalyticsClientId(){
        String clientId = pro.getProperty("LogAnalytics_client_id");
        return clientId;
    }
    public String getLogAnalyticsClientSecret(){
        String clientSecret = pro.getProperty("LogAnalytics_client_secret");
        return clientSecret;
    }
    public String getLogAnalyticsGrantType(){
        String grantType = pro.getProperty("LogAnalytics_grant_type");
        return grantType;
    }
    public String getLogAnalyticsResource(){
        String resources = pro.getProperty("LogAnalytics_resource");
        return resources;
    }
    public String getServiceBusResource(){
        String resources = pro.getProperty("https://servicebus.azure.net/");
        return resources;
    }
    
    public static String getProperty(String KeyName) {
        Properties pro = null;
        File src = new File("src/main/resources/george.Properties");
        try {
            FileInputStream fis = new FileInputStream(src);
            pro = new Properties();
            pro.load(fis);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        String key = pro.getProperty(KeyName);
        return key;
    }

}
