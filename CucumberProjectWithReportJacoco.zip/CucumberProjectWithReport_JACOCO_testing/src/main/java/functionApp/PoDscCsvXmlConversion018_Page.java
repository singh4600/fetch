package functionApp;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilClass.helperUtility;
public class PoDscCsvXmlConversion018_Page extends helperUtility{
	
	private static final Logger log = LogManager.getLogger(PoDscCsvXmlConversion018_Page.class.getName());
	
	
	

	public WebDriver driver;


	public void getAuthCode()  {
		String URL = "https://";

		System.setProperty("webdriver.chrome.silentOutput", "true");
		System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true");
		WebDriverManager.chromedriver().setup();
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--silent");
		chromeOptions.addArguments("--no-sandbox");
		chromeOptions.addArguments("--headless");
		chromeOptions.addArguments("disable-gpu");
		driver = new ChromeDriver(chromeOptions);
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		
		//log.info("code =" + code);
		driver.close();
		//log.info("chrome driver close");
		driver.quit();
		//log.info("chrome frover quit");
	}

	
}
