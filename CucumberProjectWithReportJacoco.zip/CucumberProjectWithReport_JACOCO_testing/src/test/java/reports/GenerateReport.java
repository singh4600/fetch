package reports;


import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class GenerateReport {
    public static void GenerateMasterthoughtReport(){
        try{
            SimpleDateFormat formate = new SimpleDateFormat("ddMMYYYY");
            Date date = new Date();
            String foldername = formate.format(new Date());
            String strFileString= date.toString().replace("-", "").replace(":", "").replace(".", "").replace("+", "").replace(" ","");

            File reportOutputDirectory = new File(System.getProperty("user.dir")+"/target/cucumber-reports/"+foldername);
            List<String> jsonFiles = new ArrayList<>();
            File folder = new File("target/cucumber-reports/JsonReport/");
    		File[] listOfFiles = folder.listFiles();
    		for(int i =0;i<listOfFiles.length;i++){
    			if(listOfFiles[i].getName().contains(".json")){
    				//jsonFiles.add("target/"+listOfFiles[i].getName());
                    jsonFiles.add("target/cucumber-reports/JsonReport/"+listOfFiles[i].getName());
    			}	
    		}   
            String buildNumber = "1";
            String projectName = "RFID Automation";
            boolean runWithJenkins = false;
            boolean parallelTesting = false;

            Configuration configuration = new Configuration(reportOutputDirectory, projectName);
            // optional configuration
            //configuration.setParallelTesting(parallelTesting);
            //configuration.setRunWithJenkins(runWithJenkins);
            configuration.setBuildNumber(buildNumber);
            ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
           reportBuilder.generateReports();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
