package global;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class applicationHook {
	
	private static final Logger log = LogManager.getLogger(applicationHook.class.getName());
	

	@Before()
	public void getScenarioName(Scenario scenario) {
		log.info("****************************************************************************************");
		log.info("$$$$$$$$$$ Start of execution of scenario with name :: " + scenario.getName() + " $$$$$$$$$$");
		log.info("****************************************************************************************");


	}

	//@BeforeStep(order = 0)
		public String getScenarioStepsName(Method method ) {
			String annotationValue = null;
			Annotation[] annotations = method.getDeclaredAnnotations();
			for(Annotation annotation : annotations){    
				if(annotation instanceof Given){        
					Given givenAnnotation = method.getAnnotation(Given.class);
					annotationValue = givenAnnotation.value();    
				}else if(annotation instanceof When){     
					When whenAnnotation = method.getAnnotation(When.class);  
					annotationValue = whenAnnotation.value();      
				}else if(annotation instanceof  Then){       
					Then thenAnnotation = method.getAnnotation(Then.class);   
					annotationValue = thenAnnotation.value();     
				}else if(annotation instanceof And){     
					And andAnnotation = method.getAnnotation(And.class);    
					annotationValue = andAnnotation.value();   
				}}
			return annotationValue;

		}

	//@BeforeStep(order = 1)
	public void getScenarioStepsName1() {
		log.info("Step :: ");
		//log.info("Step :: "+StepDetails.stepName);
		//log.info("=== Scenario  ::  "+sce.getId().toString()+"  =============================");

	}

	//@AfterStep
	public void endScenarioSteps(Scenario sce) {
		log.info("End Step :: "+sce);
	}

	@After
	public void tearDown(Scenario scenario) throws Exception {
		log.info("****************************************************************************************");
		log.info("$$$$$$$$$$ Completion of execution of scenario with name:: " + scenario.getName() + "  $$$$$$$$$$$");
		log.info("****************************************************************************************");
		/*
		 * if (scenario.isFailed()) { log.info(
		 * "****************************************************************************************"
		 * ); log.info("$$$$$$$$$$$$$$$$$$$$$ Failing scenario with name: " +
		 * scenario.getName() + "    $$$$$$$$$$$$$$$$$$$$$$$"); log.info(
		 * "****************************************************************************************"
		 * );
		 * 
		 * try { byte[] screenshot = ((TakesScreenshot)
		 * driver).getScreenshotAs(OutputType.BYTES); scenario.embed(screenshot,
		 * "image/png"); } catch (WebDriverException
		 * somePlatformsDontSupportScreenshots) {
		 * System.err.println(somePlatformsDontSupportScreenshots.getMessage()); }
		 * 
		 * }
		 */
		log.info(scenario.getName() +" :: "+scenario.getStatus());
		log.info("\n<<<======================================================:: END ::======================================================>>>\n");
	}
}