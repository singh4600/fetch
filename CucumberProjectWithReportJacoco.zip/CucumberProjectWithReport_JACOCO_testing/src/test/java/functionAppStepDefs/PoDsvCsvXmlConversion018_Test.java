package functionAppStepDefs;


import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.cucumber.java.en.Given;
import utilClass.helperUtility;


public class PoDsvCsvXmlConversion018_Test extends helperUtility{
	
	private static final Logger log = LogManager.getLogger(PoDsvCsvXmlConversion018_Test.class.getName());




    @Given("using clientid and redirecturi authorization code is created")
    public void createauthcode() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException, InterruptedException {
        log.info("Step :: using clientid and redirecturi authorization code is created");
    	
    	String test= new Object() {}.getClass().getEnclosingMethod().getName();
    	log.info("Get StepsDef Method Name ::  "+test+"");
    	
       
    }

  
}
