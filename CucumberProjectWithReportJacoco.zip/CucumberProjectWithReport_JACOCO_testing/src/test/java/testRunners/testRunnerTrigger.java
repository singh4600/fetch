package testRunners;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.cucumber.testng.CucumberFeatureWrapper;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.PickleEventWrapper;
import io.cucumber.testng.TestNGCucumberRunner;

@CucumberOptions(
        glue = {"global","functionAppStepDefs"},
        dryRun= false,
        monochrome = true,
        tags= "@trigger1",
        features = {

                "src/test/resources/features/functionApps/G_OMS_FunApp_PoDsvXmlCsvConversion_IFDD_0018.feature"
               

        },
        plugin = {
                "summary",
                "pretty" ,
                "html:target/cucumber-reports/cucumber-pretty/",
                "json:target/cucumber-reports/JsonReport/CucumberTestReport.json"

        }
)

public class testRunnerTrigger {
    private static final Logger log = LogManager.getLogger(testRunner.class.getName());

    public TestNGCucumberRunner testNGCucumberRunner;

    @BeforeClass(alwaysRun = true)
    public void setUpClass() throws Exception {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }

    @Test(groups = "Cucumber", description = "Runs Cucumber Feature", dataProvider = "scenarios")
    public void scenario(PickleEventWrapper pickleEvent, CucumberFeatureWrapper cucumberFeature) throws Throwable {
        log.info("STARTING THIS FEATURE >>>>>" + cucumberFeature + "<<<<<<<<<<<<<<<<<<<<<<<<<<");
        testNGCucumberRunner.runScenario(pickleEvent.getPickleEvent());
    }

    @DataProvider
    public Object[][] scenarios() {
        return testNGCucumberRunner.provideScenarios();
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() throws Exception {
        testNGCucumberRunner.finish();
    }
}




